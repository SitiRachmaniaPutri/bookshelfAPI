const { addBooksHandler, getAllBooksHandler, getBookIdHandler, editBookHandler, deleteBooksHandler, } = require('./handler');
const routes = [
    {
      method: 'GET',
      path: '/',
      handler: () => {
        return 'ini halaman home'
      }
    },
    {
      method: 'POST',
      path: '/books',
      handler: addBooksHandler,
    },
    {
      method: 'GET',
      path: '/books',
      handler: getAllBooksHandler,
    },
    {
      method: 'GET',
      path: '/books/{bookId}',
      handler: getBookIdHandler,
    },
    {
      method: 'PUT',
      path: '/books/{bookId}',
      handler: editBookHandler,
    },
    {
      method: 'DELETE',
      path: '/books/{bookId}',
      handler: deleteBooksHandler,
    }
  ];
   
  module.exports = routes;